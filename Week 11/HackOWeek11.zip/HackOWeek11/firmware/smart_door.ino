/*
 * ============================================================
 *  SMART DOOR AUTOMATION SYSTEM
 *  HackOWeek11 Project
 * ============================================================
 *  Hardware:
 *    - ESP32 / Arduino Uno/Mega
 *    - HC-SR501 PIR or IR Proximity Sensor (GPIO 14)
 *    - SG90 / MG996R Servo Motor          (GPIO 13)
 *    - 16x2 I2C LCD Display               (SDA=21, SCL=22)
 *    - Buzzer (optional)                   (GPIO 12)
 *    - LED indicator                       (GPIO 2)
 *    - WiFi (ESP32 only) for HTTP logging
 *
 *  Author : HackOWeek11 Team
 *  Date   : 2026-04-02
 * ============================================================
 */

#include <ESP32Servo.h>       // Use <Servo.h> for Arduino Uno/Mega
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <time.h>

// ============================================================
//  CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* LOG_SERVER    = "http://192.168.1.100:3000/api/log"; // Dashboard server

// GPIO Pins
#define IR_SENSOR_PIN   14
#define SERVO_PIN       13
#define BUZZER_PIN      12
#define LED_PIN          2

// Servo Angles
#define DOOR_OPEN_ANGLE   90    // degrees — door open
#define DOOR_CLOSED_ANGLE  0    // degrees — door closed

// Timing
#define DOOR_OPEN_DURATION_MS  5000  // Hold door open for 5 seconds
#define DEBOUNCE_MS             500  // Sensor debounce
#define SENSOR_CHECK_INTERVAL   100  // ms between sensor reads

// ============================================================
//  HARDWARE OBJECTS
// ============================================================
Servo           doorServo;
LiquidCrystal_I2C lcd(0x27, 16, 2);   // adjust address if needed (0x3F common)

// ============================================================
//  STATE MACHINE
// ============================================================
enum DoorState {
  DOOR_IDLE,        // Waiting for detection
  DOOR_OPENING,     // Servo moving to open
  DOOR_OPEN,        // Door fully open, timer running
  DOOR_CLOSING,     // Servo moving to closed
};

DoorState     currentState    = DOOR_IDLE;
unsigned long doorOpenedAt    = 0;
unsigned long lastSensorCheck = 0;
unsigned long lastDetection   = 0;
bool          sensorTriggered = false;
uint32_t      eventCount      = 0;

// ============================================================
//  FORWARD DECLARATIONS
// ============================================================
void openDoor();
void closeDoor();
void logEvent(const char* eventType, const char* detail);
void updateLCD(const char* line1, const char* line2);
void beep(int times, int durationMs);
String getTimestamp();
void connectWiFi();
void syncTime();

// ============================================================
//  SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  Serial.println("=== Smart Door Automation System ===");
  Serial.println("Initializing...");

  // GPIO
  pinMode(IR_SENSOR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // Servo — attach and move to closed position
  doorServo.attach(SERVO_PIN);
  doorServo.write(DOOR_CLOSED_ANGLE);
  delay(500);

  // LCD
  lcd.init();
  lcd.backlight();
  updateLCD("Smart Door", "Initializing...");

  // WiFi
  connectWiFi();
  syncTime();

  // Ready
  updateLCD("Smart Door", "Ready");
  beep(2, 100);
  Serial.println("System Ready.");
  logEvent("SYSTEM_START", "Smart door system initialized");
}

// ============================================================
//  MAIN LOOP
// ============================================================
void loop() {
  unsigned long now = millis();

  // ── Read IR Sensor (with debounce) ──
  if (now - lastSensorCheck >= SENSOR_CHECK_INTERVAL) {
    lastSensorCheck = now;
    int sensorVal = digitalRead(IR_SENSOR_PIN);   // HIGH = object detected

    if (sensorVal == HIGH && (now - lastDetection) > DEBOUNCE_MS) {
      if (!sensorTriggered) {
        sensorTriggered = true;
        lastDetection   = now;
        Serial.println("[SENSOR] Proximity detected!");
      }
    } else if (sensorVal == LOW) {
      sensorTriggered = false;
    }
  }

  // ── State Machine ──
  switch (currentState) {

    case DOOR_IDLE:
      if (sensorTriggered) {
        Serial.println("[STATE] IDLE → OPENING");
        currentState = DOOR_OPENING;
        openDoor();
      }
      break;

    case DOOR_OPENING:
      // openDoor() is blocking; transition happens inside it
      break;

    case DOOR_OPEN:
      // Keep door open; reset timer if sensor still active
      if (sensorTriggered) {
        doorOpenedAt = now;   // extend open window
      }
      if (now - doorOpenedAt >= DOOR_OPEN_DURATION_MS) {
        Serial.println("[STATE] OPEN → CLOSING");
        currentState = DOOR_CLOSING;
        closeDoor();
      }
      break;

    case DOOR_CLOSING:
      // closeDoor() is blocking; returns to IDLE
      break;
  }

  // ── Heartbeat LED ──
  digitalWrite(LED_PIN, (now / 1000) % 2 == 0 ? HIGH : LOW);

  // ── Serial Commands (debug) ──
  if (Serial.available()) {
    char cmd = Serial.read();
    if (cmd == 'o') { openDoor();  }
    if (cmd == 'c') { closeDoor(); }
    if (cmd == 's') { Serial.println(getTimestamp()); }
  }
}

// ============================================================
//  DOOR CONTROL
// ============================================================
void openDoor() {
  Serial.println("[DOOR] Opening...");
  updateLCD("DOOR STATUS:", ">> Opening...");
  beep(1, 150);

  // Smooth servo sweep to open
  int currentAngle = doorServo.read();
  for (int angle = currentAngle; angle <= DOOR_OPEN_ANGLE; angle++) {
    doorServo.write(angle);
    delay(10);  // ~10ms per degree ≈ 0.9s sweep
  }

  doorOpenedAt = millis();
  currentState = DOOR_OPEN;
  eventCount++;

  Serial.printf("[DOOR] Open ✓  (event #%u)\n", eventCount);
  updateLCD("DOOR: OPEN", getTimestamp().c_str());
  logEvent("DOOR_OPEN", ("Event #" + String(eventCount)).c_str());
}

void closeDoor() {
  Serial.println("[DOOR] Closing...");
  updateLCD("DOOR STATUS:", "<< Closing...");
  beep(2, 80);

  // Smooth servo sweep to closed
  int currentAngle = doorServo.read();
  for (int angle = currentAngle; angle >= DOOR_CLOSED_ANGLE; angle--) {
    doorServo.write(angle);
    delay(10);
  }

  currentState    = DOOR_IDLE;
  sensorTriggered = false;

  Serial.println("[DOOR] Closed ✓");
  updateLCD("DOOR: CLOSED", "Waiting...");
  logEvent("DOOR_CLOSE", ("After event #" + String(eventCount)).c_str());
}

// ============================================================
//  EVENT LOGGING (Serial + HTTP POST to Dashboard)
// ============================================================
void logEvent(const char* eventType, const char* detail) {
  String ts = getTimestamp();
  Serial.printf("[LOG] %s | %s | %s\n", ts.c_str(), eventType, detail);

  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.begin(LOG_SERVER);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> doc;
  doc["timestamp"] = ts;
  doc["event"]     = eventType;
  doc["detail"]    = detail;
  doc["count"]     = eventCount;

  String body;
  serializeJson(doc, body);

  int code = http.POST(body);
  Serial.printf("[HTTP] POST → %d\n", code);
  http.end();
}

// ============================================================
//  LCD HELPER
// ============================================================
void updateLCD(const char* line1, const char* line2) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(line1);
  lcd.setCursor(0, 1);
  lcd.print(line2);
}

// ============================================================
//  BUZZER
// ============================================================
void beep(int times, int durationMs) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(durationMs);
    digitalWrite(BUZZER_PIN, LOW);
    if (i < times - 1) delay(100);
  }
}

// ============================================================
//  WIFI
// ============================================================
void connectWiFi() {
  Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] Connected! IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[WiFi] Failed — offline mode.");
  }
}

// ============================================================
//  NTP TIME SYNC
// ============================================================
void syncTime() {
  configTime(19800, 0, "pool.ntp.org", "time.nist.gov");  // UTC+5:30 (IST)
  Serial.print("[NTP] Syncing time");
  struct tm ti;
  int attempts = 0;
  while (!getLocalTime(&ti) && attempts < 10) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  Serial.println(getLocalTime(&ti) ? " OK" : " Failed");
}

String getTimestamp() {
  struct tm ti;
  if (!getLocalTime(&ti)) return "00:00:00";
  char buf[20];
  strftime(buf, sizeof(buf), "%H:%M:%S", &ti);
  return String(buf);
}
