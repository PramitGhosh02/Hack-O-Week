/**
 * Smart Door Automation — Backend Server
 * HackOWeek11
 *
 * Routes:
 *   POST /api/log          ← receives events from ESP32
 *   GET  /api/events       ← fetch all logged events
 *   GET  /api/stats        ← summary statistics
 *   GET  /                 ← serves the dashboard HTML
 *
 * Real-time: Socket.IO pushes every new event to all connected browsers.
 */

const express    = require('express');
const cors       = require('cors');
const bodyParser = require('body-parser');
const http       = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const path       = require('path');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });

const PORT = 3000;

// ── Middleware ──────────────────────────────────────────────
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── In-memory Event Store ───────────────────────────────────
let events = [];
let stats = {
  totalOpenings: 0,
  totalClosings: 0,
  systemStarts:  0,
  lastEvent:     null,
  uptime:        Date.now(),
};

// Seed with some demo events for UI testing
function seedDemoEvents() {
  const types = ['DOOR_OPEN', 'DOOR_CLOSE', 'DOOR_OPEN', 'DOOR_CLOSE', 'SYSTEM_START'];
  const details = [
    'Event #1', 'After event #1',
    'Event #2', 'After event #2',
    'Smart door system initialized',
  ];
  const now = Date.now();
  types.forEach((type, i) => {
    const ts = new Date(now - (types.length - i) * 45000);
    const ev = {
      id:        uuidv4(),
      timestamp: ts.toISOString(),
      localTime: ts.toLocaleTimeString('en-IN'),
      event:     type,
      detail:    details[i] || '',
      count:     i,
    };
    events.push(ev);
    if (type === 'DOOR_OPEN')    stats.totalOpenings++;
    if (type === 'DOOR_CLOSE')   stats.totalClosings++;
    if (type === 'SYSTEM_START') stats.systemStarts++;
  });
  stats.lastEvent = events[events.length - 1];
}
seedDemoEvents();

// ── POST /api/log ────────────────────────────────────────────
app.post('/api/log', (req, res) => {
  const { timestamp, event, detail, count } = req.body;

  if (!event) return res.status(400).json({ error: 'event is required' });

  const ev = {
    id:        uuidv4(),
    timestamp: new Date().toISOString(),
    localTime: timestamp || new Date().toLocaleTimeString('en-IN'),
    event,
    detail:    detail || '',
    count:     count  || 0,
  };

  events.push(ev);
  if (events.length > 500) events.shift();  // rolling window

  // Update stats
  if (event === 'DOOR_OPEN')    stats.totalOpenings++;
  if (event === 'DOOR_CLOSE')   stats.totalClosings++;
  if (event === 'SYSTEM_START') stats.systemStarts++;
  stats.lastEvent = ev;

  // Broadcast to all dashboard clients
  io.emit('new_event', ev);
  io.emit('stats_update', buildStats());

  console.log(`[LOG] ${ev.localTime} | ${event} | ${detail}`);
  res.json({ success: true, id: ev.id });
});

// ── GET /api/events ──────────────────────────────────────────
app.get('/api/events', (req, res) => {
  const limit = parseInt(req.query.limit) || 100;
  res.json(events.slice(-limit).reverse());
});

// ── GET /api/stats ───────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  res.json(buildStats());
});

// ── Simulate endpoint (for demo/testing without hardware) ────
app.post('/api/simulate', (req, res) => {
  const { action } = req.body;  // 'open' | 'close' | 'detect'
  const map = {
    open:   { event: 'DOOR_OPEN',     detail: `Simulated — Event #${stats.totalOpenings + 1}` },
    close:  { event: 'DOOR_CLOSE',    detail: `Simulated — After event #${stats.totalOpenings}` },
    detect: { event: 'IR_DETECTED',   detail: 'Simulated IR proximity trigger' },
    start:  { event: 'SYSTEM_START',  detail: 'Simulated system restart' },
  };
  const entry = map[action] || map['detect'];
  req.body = { ...entry };
  // Re-use the log handler logic inline
  const ev = {
    id:        uuidv4(),
    timestamp: new Date().toISOString(),
    localTime: new Date().toLocaleTimeString('en-IN'),
    event:     entry.event,
    detail:    entry.detail,
    count:     stats.totalOpenings,
  };
  events.push(ev);
  if (entry.event === 'DOOR_OPEN')    stats.totalOpenings++;
  if (entry.event === 'DOOR_CLOSE')   stats.totalClosings++;
  if (entry.event === 'SYSTEM_START') stats.systemStarts++;
  stats.lastEvent = ev;
  io.emit('new_event', ev);
  io.emit('stats_update', buildStats());
  res.json({ success: true, id: ev.id });
});

// ── Socket.IO ────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[WS] Client connected: ${socket.id}`);
  socket.emit('init', { events: events.slice(-50).reverse(), stats: buildStats() });
  socket.on('disconnect', () => console.log(`[WS] Client disconnected: ${socket.id}`));
});

// ── Helper ───────────────────────────────────────────────────
function buildStats() {
  const uptimeSec = Math.floor((Date.now() - stats.uptime) / 1000);
  const hh = Math.floor(uptimeSec / 3600);
  const mm = Math.floor((uptimeSec % 3600) / 60);
  const ss = uptimeSec % 60;
  return {
    totalOpenings: stats.totalOpenings,
    totalClosings: stats.totalClosings,
    systemStarts:  stats.systemStarts,
    totalEvents:   events.length,
    lastEvent:     stats.lastEvent,
    uptime:        `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`,
  };
}

// ── Start ────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log(`\n✅  Smart Door Dashboard running at http://localhost:${PORT}`);
  console.log(`   POST /api/log      → receive events from ESP32`);
  console.log(`   GET  /api/events   → list all events`);
  console.log(`   GET  /api/stats    → statistics`);
  console.log(`   POST /api/simulate → inject test events\n`);
});
