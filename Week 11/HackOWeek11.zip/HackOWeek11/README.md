# 🚪 Smart Door Automation System
### HackOWeek11 Project

A complete IoT door automation system using an **IR Proximity Sensor**, **Servo Motor**, and a **Real-time Web Dashboard** with event logging.

---

## 📐 System Architecture

```
┌─────────────┐     IR Trigger     ┌──────────────────┐
│  IR Sensor  │ ─────────────────► │                  │
│ (HC-SR501)  │                    │   ESP32 / Arduino │
└─────────────┘                    │                  │
                                   │  State Machine:  │
┌─────────────┐     PWM Signal     │  IDLE→OPENING    │
│ Servo Motor │ ◄────────────────  │  OPENING→OPEN    │
│  (SG90)     │                    │  OPEN→CLOSING    │
└─────────────┘                    │  CLOSING→IDLE    │
                                   └───────┬──────────┘
┌─────────────┐     I2C            HTTP POST (WiFi)  │
│  LCD 16x2   │ ◄────────────────  ▼                  │
│  Display    │           ┌────────────────┐          │
└─────────────┘           │  Node.js Server│          │
                          │  + Socket.IO   │          │
                          │  Port 3000     │          │
                          └────────┬───────┘          │
                                   │ WebSocket         │
                          ┌────────▼───────┐          │
                          │  Web Dashboard │          │
                          │  (Real-time)   │          │
                          └────────────────┘
```

---

## 🔌 Hardware Connections (ESP32)

| Component         | Pin            | Notes                         |
|-------------------|----------------|-------------------------------|
| IR Proximity Sensor | GPIO 14 (IN) | HC-SR501 PIR or IR Break-beam |
| Servo Motor       | GPIO 13 (PWM)  | SG90 / MG996R                 |
| Buzzer            | GPIO 12        | Active buzzer                 |
| Status LED        | GPIO 2         | Heartbeat blink               |
| LCD SDA           | GPIO 21        | I2C Data                      |
| LCD SCL           | GPIO 22        | I2C Clock                     |
| VCC (sensor/servo)| 3.3V / 5V      | Check datasheet               |
| GND               | GND            | Common ground                 |

### Servo Motor: Door Movement
- **0°** → Door Closed
- **90°** → Door Open (smooth sweep, 10ms/degree)

---

## 📁 Project Structure

```
HackOWeek11/
├── firmware/
│   └── smart_door.ino        ← ESP32/Arduino sketch
├── dashboard/
│   ├── server.js             ← Node.js + Socket.IO backend
│   ├── package.json
│   └── public/
│       └── index.html        ← Real-time web dashboard
└── README.md
```

---

## 🚀 Getting Started

### 1. Flash the Firmware

1. Open `firmware/smart_door.ino` in **Arduino IDE**
2. Install required libraries via Library Manager:
   - `ESP32Servo`
   - `LiquidCrystal I2C`
   - `ArduinoJson`
3. Update WiFi credentials in the sketch:
   ```cpp
   const char* WIFI_SSID     = "YOUR_WIFI";
   const char* WIFI_PASSWORD = "YOUR_PASSWORD";
   const char* LOG_SERVER    = "http://<YOUR_PC_IP>:3000/api/log";
   ```
4. Select Board: **ESP32 Dev Module** → Upload

### 2. Run the Dashboard

```powershell
cd dashboard
npm install
npm start
```

Open your browser → **http://localhost:3000**

### 3. Simulate Without Hardware

Use the dashboard's **Simulation Controls**:
- 🔓 Open Door
- 🔒 Close Door
- 🚶 IR Detect
- 🔄 System Start

Or via curl:
```bash
curl -X POST http://localhost:3000/api/simulate \
  -H "Content-Type: application/json" \
  -d '{"action":"open"}'
```

---

## 🌐 API Reference

| Endpoint            | Method | Description                        |
|---------------------|--------|------------------------------------|
| `/api/log`          | POST   | Receive event from ESP32           |
| `/api/events`       | GET    | Fetch all logged events            |
| `/api/stats`        | GET    | Get summary statistics             |
| `/api/simulate`     | POST   | Inject simulated event             |

### POST /api/log request body
```json
{
  "timestamp": "14:32:05",
  "event": "DOOR_OPEN",
  "detail": "Event #3",
  "count": 3
}
```

### Event Types
| Event           | Trigger                    |
|-----------------|----------------------------|
| `DOOR_OPEN`     | Servo moved to 90°         |
| `DOOR_CLOSE`    | Servo moved to 0°          |
| `IR_DETECTED`   | IR sensor proximity trigger|
| `SYSTEM_START`  | ESP32 boot                 |

---

## 📊 Dashboard Features

- 🚪 **Animated door** with real-time open/close visualization
- 📡 **IR sensor beam** visualizer with trigger animation
- ⚙️ **Servo gauge** showing current angle (0°–90°)
- 📊 **Activity chart** — last 20 door events
- 📋 **Event log table** with filtering and timestamps
- 📈 **Live statistics** — total opens, closes, uptime
- 🔔 **Toast notifications** for every incoming event
- 🎮 **Simulation controls** — test without hardware

---

## 🔄 Door State Machine

```
      IR Detected
IDLE ─────────────► OPENING
                        │
               Servo at 90°
                        ▼
                      OPEN ◄──── IR still active (timer resets)
                        │
               5s timeout
                        ▼
                    CLOSING
                        │
               Servo at 0°
                        ▼
                      IDLE
```

---

## 👥 Team

**HackOWeek11 Submission**  
Smart Door Automation using IR Proximity Sensor + Servo Motor + ESP32

---

*Built with ❤️ for HackOWeek11*
